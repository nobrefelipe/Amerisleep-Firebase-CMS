
import firebaseApp from './firebase';

let db = firebaseApp.database();

export default db;