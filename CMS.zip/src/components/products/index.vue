<template src="./products.component.html"></template>
<script src="./products.component.js"></script>

