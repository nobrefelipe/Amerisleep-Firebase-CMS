<template src="./login.component.html"></template>
<script src="./login.component.js"></script>
<style>

    .invalid{
        border-color: red;
    }

    .invalid:focus{
        border-color: grey !important;
    }


</style>

