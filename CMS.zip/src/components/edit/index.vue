<template src="./edit.component.html"></template>
<script src="./edit.component.js"></script>
<style>
  input{padding: 6px}
</style>
