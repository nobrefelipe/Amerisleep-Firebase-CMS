import Vue from 'vue';

export default{

    param: this.$route.params.product

}